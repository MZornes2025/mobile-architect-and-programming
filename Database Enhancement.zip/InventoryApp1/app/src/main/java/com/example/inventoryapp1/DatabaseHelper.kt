package com.example.inventoryapp1

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VER) {

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table with initial schema
        db.execSQL("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """.trimIndent())

        // Create items table
        db.execSQL("""
            CREATE TABLE items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                category TEXT
            )
        """.trimIndent())

        Log.d("DatabaseHelper", "Database created with version $DB_VER")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.d("DatabaseHelper", "Upgrading database from version $oldVersion to $newVersion")

        // Implement proper migration strategy instead of dropping tables
        when (oldVersion) {
            1 -> {
                // Migration from version 1 to 2
                // In a production app, we would migrate existing plain text passwords to hashes
                // For this enhancement, we'll keep the existing structure but demonstrate migration pattern
                Log.d("DatabaseHelper", "Running migration from version 1 to 2")
                // Example: db.execSQL("ALTER TABLE users ADD COLUMN email TEXT")
                // For now, we're just updating the password storage through the repository
            }

        }

        Log.d("DatabaseHelper", "Database upgrade completed")
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Handle database downgrade if needed
        Log.w("DatabaseHelper", "Database downgrade from $oldVersion to $newVersion - recreating tables")
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS items")
        onCreate(db)
    }

    companion object {
        const val DB_NAME = "app_db.sqlite"
        const val DB_VER = 2 // Incremented version for migration demonstration
    }
}