package com.example.inventoryapp1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(
    private val items: MutableList<InventoryItem>,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = items[position]
        holder.itemName.setText(item.name)
        holder.itemQuantity.setText(item.quantity.toString())

        holder.deleteButton.setOnClickListener {
            onDeleteClick(position)
        }
    }

    override fun getItemCount(): Int = items.size

    inner class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemName: EditText = view.findViewById(R.id.itemName)
        val itemQuantity: EditText = view.findViewById(R.id.itemQuantity)
        val deleteButton: Button = view.findViewById(R.id.deleteButton)
    }
}
