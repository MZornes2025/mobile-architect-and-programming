package com.example.inventoryapp1

data class Item(
    val name: String,
    val quantity: String
)
