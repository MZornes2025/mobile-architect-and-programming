package com.example.inventoryapp1

data class User(
    val id: Long,
    val username: String,
    val password: String // For coursework simplicity; in production, store a hash
)
