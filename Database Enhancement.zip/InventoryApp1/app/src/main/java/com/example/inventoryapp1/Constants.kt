package com.example.inventoryapp1

/**
 * Centralized constants for the application
 * Provides a single source of truth for configurable values
 */
object Constants {
    // Inventory settings
    const val LOW_STOCK_THRESHOLD = 5

    // Database settings
    const val DATABASE_VERSION = 2
    const val DATABASE_NAME = "app_db.sqlite"

    // Security settings
    const val BCRYPT_COST_FACTOR = 12

    // Validation settings
    const val MIN_PASSWORD_LENGTH = 3 // For demo purposes; production should be higher
    const val MIN_USERNAME_LENGTH = 3
}