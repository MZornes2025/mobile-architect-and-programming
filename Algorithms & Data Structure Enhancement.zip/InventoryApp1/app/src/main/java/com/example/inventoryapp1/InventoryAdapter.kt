package com.example.inventoryapp1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val onUpdateClick: (item: InventoryItem, newName: String, newQuantity: Int) -> Unit,
    private val onDeleteClick: (item: InventoryItem) -> Unit
) : ListAdapter<InventoryItem, InventoryAdapter.InventoryViewHolder>(InventoryDiffCallback()) {

    // Inner class for the DiffUtil ItemCallback
    class InventoryDiffCallback : DiffUtil.ItemCallback<InventoryItem>() {
        override fun areItemsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InventoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.inventory_item, parent, false)
        return InventoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: InventoryViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class InventoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val itemName: EditText = view.findViewById(R.id.itemNameEdit)
        private val itemQuantity: EditText = view.findViewById(R.id.itemQuantityEdit)
        private val updateButton: Button = view.findViewById(R.id.updateButton)
        private val deleteButton: Button = view.findViewById(R.id.deleteButton)

        fun bind(item: InventoryItem) {
            itemName.setText(item.name)
            itemQuantity.setText(item.quantity.toString())

            updateButton.setOnClickListener {
                val name = itemName.text.toString().trim()
                val qtyText = itemQuantity.text.toString().trim()

                // Input validation
                if (name.isEmpty()) {
                    Toast.makeText(itemView.context, "Item name cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val qty = qtyText.toIntOrNull()
                if (qty == null || qty < 0) {
                    Toast.makeText(itemView.context, "Quantity must be a positive number", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                onUpdateClick(item, name, qty)
                Toast.makeText(itemView.context, "Item updated successfully", Toast.LENGTH_SHORT).show()
            }

            deleteButton.setOnClickListener {
                onDeleteClick(item)
                Toast.makeText(itemView.context, "Item deleted", Toast.LENGTH_SHORT).show()
            }
        }
    }
}