package com.example.inventoryapp1

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: InventoryAdapter
    private lateinit var itemNameEditText: EditText
    private lateinit var itemQuantityEditText: EditText
    private lateinit var addItemButton: Button
    private lateinit var phoneNumberEt: EditText
    private lateinit var smsSwitch: Switch

    private lateinit var inventoryRepo: InventoryRepository

    private val smsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(
            this,
            if (granted) "SMS permission granted" else "SMS permission denied",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        inventoryRepo = InventoryRepository(this)

        recyclerView = findViewById(R.id.recyclerView)
        itemNameEditText = findViewById(R.id.editItemName)
        itemQuantityEditText = findViewById(R.id.editItemQuantity)
        addItemButton = findViewById(R.id.addItemButton)
        phoneNumberEt = findViewById(R.id.editAlertPhone)
        smsSwitch = findViewById(R.id.switchSmsAlerts)

        // Initialize the adapter
        adapter = InventoryAdapter(
            onUpdateClick = { item, newName, newQty ->
                val updated = item.copy(name = newName, quantity = newQty)
                if (inventoryRepo.update(updated)) {
                    loadItemsFromDatabase() // Reload items to reflect changes
                    Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show()
                    maybeSendLowStockAlert(updated)
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
                }
            },
            onDeleteClick = { item ->
                if (inventoryRepo.delete(item.id)) {
                    loadItemsFromDatabase() // Reload items to reflect deletion
                    Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                }
            }
        )

        recyclerView.layoutManager = GridLayoutManager(this, 1)
        recyclerView.adapter = adapter

        // Load initial items from database
        loadItemsFromDatabase()

        addItemButton.setOnClickListener {
            val name = itemNameEditText.text.toString().trim()
            val quantityStr = itemQuantityEditText.text.toString().trim()

            // Comprehensive input validation
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val qty = quantityStr.toIntOrNull()
            if (qty == null || qty < 0) {
                Toast.makeText(this, "Quantity must be a positive number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newId = inventoryRepo.add(InventoryItem(id = 0, name = name, quantity = qty, category = null))
            if (newId > 0) {
                val added = InventoryItem(newId, name, qty, null)
                loadItemsFromDatabase() // Reload to show new item
                itemNameEditText.text.clear()
                itemQuantityEditText.text.clear()
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show()
                maybeSendLowStockAlert(added)
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show()
            }
        }

        // Ask for SMS permission when user enables alerts
        smsSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                ensureSmsPermission()
            }
        }
    }

    private fun loadItemsFromDatabase() {
        val items = inventoryRepo.getAll()
        adapter.submitList(items) // This triggers DiffUtil to calculate changes efficiently
    }

    private fun ensureSmsPermission() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
        }
    }

    private fun maybeSendLowStockAlert(item: InventoryItem) {
        // Only if user wants alerts AND we have permission AND quantity is low
        val enabled = smsSwitch.isChecked
        val phone = phoneNumberEt.text?.toString()?.trim().orEmpty()
        val lowThreshold = Constants.LOW_STOCK_THRESHOLD
        if (!enabled || phone.isEmpty() || item.quantity >= lowThreshold) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            val msg = "Low stock alert: '${item.name}' is at ${item.quantity}."
            try {
                SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null)
                Toast.makeText(this, "Low-stock SMS sent", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "SMS send failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show()
        }
    }
}