package com.example.inventoryapp1

import android.content.ContentValues
import android.content.Context
import android.database.Cursor

class UserRepository(context: Context) {
    private val dbHelper = DatabaseHelper(context)

    fun register(username: String, password: String): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        return try {
            db.insertOrThrow("users", null, values) > 0
        } catch (_: Exception) {
            false
        }
    }

    fun login(username: String, password: String): Boolean {
        val db = dbHelper.readableDatabase
        val c: Cursor = db.rawQuery(
            "SELECT id FROM users WHERE username=? AND password=? LIMIT 1",
            arrayOf(username, password)
        )
        c.use {
            return it.moveToFirst()
        }
    }
}
