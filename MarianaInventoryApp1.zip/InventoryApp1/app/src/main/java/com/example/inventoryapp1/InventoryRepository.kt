package com.example.inventoryapp1

import android.content.ContentValues
import android.content.Context
import android.database.Cursor

class InventoryRepository(context: Context) {
    private val dbHelper = DatabaseHelper(context)

    fun getAll(): List<InventoryItem> {
        val db = dbHelper.readableDatabase
        val list = mutableListOf<InventoryItem>()
        val c: Cursor = db.rawQuery("SELECT id, name, quantity, category FROM items ORDER BY id DESC", null)
        c.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val name = it.getString(1)
                val qty = it.getInt(2)
                val cat = if (!it.isNull(3)) it.getString(3) else null
                list.add(InventoryItem(id, name, qty, cat))
            }
        }
        return list
    }

    fun add(item: InventoryItem): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", item.name)
            put("quantity", item.quantity)
            put("category", item.category)
        }
        return db.insert("items", null, values)
    }

    fun update(item: InventoryItem): Boolean {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", item.name)
            put("quantity", item.quantity)
            put("category", item.category)
        }
        val rows = db.update("items", values, "id=?", arrayOf(item.id.toString()))
        return rows > 0
    }

    fun delete(id: Long): Boolean {
        val db = dbHelper.writableDatabase
        val rows = db.delete("items", "id=?", arrayOf(id.toString()))
        return rows > 0
    }
}
