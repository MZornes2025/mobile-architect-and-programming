package com.example.inventoryapp1

import android.content.ContentValues
import android.database.Cursor
import android.content.Context

class UserRepository(context: Context) : BaseRepository(context) {

    fun register(username: String, password: String): Boolean {
        val values = ContentValues().apply {
            put("username", username)
            put("password", password) // Still plain text. Enhancement to be done for Databases milestone.
        }
        return insert("users", values) > 0
    }

    fun login(username: String, password: String): Boolean {
        val c: Cursor = rawQuery(
            "SELECT id FROM users WHERE username=? AND password=? LIMIT 1",
            arrayOf(username, password)
        )
        c.use {
            return it.moveToFirst()
        }
    }
}