package com.example.inventoryapp1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var usernameEt: EditText
    private lateinit var passwordEt: EditText
    private lateinit var userRepo: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        userRepo = UserRepository(this)

        usernameEt = findViewById(R.id.usernameEditText)
        passwordEt = findViewById(R.id.passwordEditText)

        findViewById<Button>(R.id.loginButton).setOnClickListener {
            val u = usernameEt.text.toString().trim()
            val p = passwordEt.text.toString().trim()
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (userRepo.login(u, p)) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, DashboardActivity::class.java))
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.registerButton).setOnClickListener {
            val u = usernameEt.text.toString().trim()
            val p = passwordEt.text.toString().trim()

            // Enhanced validation
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (u.length < Constants.MIN_USERNAME_LENGTH) {
                Toast.makeText(this, "Username must be at least ${Constants.MIN_USERNAME_LENGTH} characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (p.length < Constants.MIN_PASSWORD_LENGTH) {
                Toast.makeText(this, "Password must be at least ${Constants.MIN_PASSWORD_LENGTH} characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if username already exists
            if (userRepo.usernameExists(u)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val created = userRepo.register(u, p)
            if (created) {
                Toast.makeText(this, "Account created! You can log in now.", Toast.LENGTH_SHORT).show()
                // Clear password field for security
                passwordEt.text.clear()
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}