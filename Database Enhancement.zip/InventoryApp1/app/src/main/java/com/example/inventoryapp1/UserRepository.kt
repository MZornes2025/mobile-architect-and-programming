package com.example.inventoryapp1

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.util.Log

class UserRepository(context: Context) : BaseRepository(context) {

    /**
     * Registers a new user with hashed password storage
     * @param username the user's username
     * @param password the plain text password to hash and store
     * @return true if registration successful, false otherwise
     */
    fun register(username: String, password: String): Boolean {
        // Hash the password before storage
        val hashedPassword = PasswordHasher.hashPassword(password)

        val values = ContentValues().apply {
            put("username", username)
            put("password", hashedPassword) // Store the hashed password, not plain text
        }

        return try {
            val result = insert("users", values) > 0
            if (result) {
                Log.d("UserRepository", "User '$username' registered successfully")
            } else {
                Log.w("UserRepository", "Failed to register user '$username'")
            }
            result
        } catch (e: Exception) {
            Log.e("UserRepository", "Error registering user '$username': ${e.message}")
            false
        }
    }

    /**
     * Authenticates a user by verifying the password against the stored hash
     * @param username the user's username
     * @param password the plain text password to verify
     * @return true if authentication successful, false otherwise
     */
    fun login(username: String, password: String): Boolean {
        val c: Cursor = rawQuery(
            "SELECT password FROM users WHERE username=? LIMIT 1",
            arrayOf(username)
        )

        c.use {
            return if (it.moveToFirst()) {
                val storedHash = it.getString(0)
                val isValid = PasswordHasher.verifyPassword(password, storedHash)

                if (isValid) {
                    Log.d("UserRepository", "User '$username' logged in successfully")
                } else {
                    Log.w("UserRepository", "Invalid password for user '$username'")
                }
                isValid
            } else {
                Log.w("UserRepository", "User '$username' not found")
                false
            }
        }
    }

    /**
     * Checks if a username already exists
     * @param username the username to check
     * @return true if username exists, false otherwise
     */
    fun usernameExists(username: String): Boolean {
        val c: Cursor = rawQuery(
            "SELECT id FROM users WHERE username=? LIMIT 1",
            arrayOf(username)
        )

        c.use {
            return it.moveToFirst()
        }
    }
}