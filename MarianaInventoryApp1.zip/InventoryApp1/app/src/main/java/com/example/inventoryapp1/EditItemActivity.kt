package com.example.inventoryapp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EditItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_item)
    }
}