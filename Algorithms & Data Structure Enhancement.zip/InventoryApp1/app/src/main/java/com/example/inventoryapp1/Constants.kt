package com.example.inventoryapp1

object Constants {
    const val LOW_STOCK_THRESHOLD = 5
}