package com.example.inventoryapp1

import at.favre.lib.crypto.bcrypt.BCrypt

/**
 * Utility object for handling password hashing and verification using BCrypt.
 * Provides secure password storage by hashing plain text passwords with salt.
 */
object PasswordHasher {

    /**
     * Hashes a plain text password using BCrypt with a work factor of 12
     * @param password the plain text password to hash
     * @return the hashed password string in BCrypt format
     */
    fun hashPassword(password: String): String {
        return BCrypt.withDefaults().hashToString(12, password.toCharArray())
    }

    /**
     * Verifies a plain text password against a stored BCrypt hash
     * @param password the plain text password to verify
     * @param hash the stored BCrypt hash to compare against
     * @return true if the password matches the hash, false otherwise
     */
    fun verifyPassword(password: String, hash: String): Boolean {
        return BCrypt.verifyer().verify(password.toCharArray(), hash).verified
    }
}