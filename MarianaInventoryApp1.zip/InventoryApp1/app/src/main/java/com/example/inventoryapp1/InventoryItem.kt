package com.example.inventoryapp1

data class InventoryItem(
    val id: Long,
    var name: String,
    var quantity: Int,
    var category: String? = null
)
