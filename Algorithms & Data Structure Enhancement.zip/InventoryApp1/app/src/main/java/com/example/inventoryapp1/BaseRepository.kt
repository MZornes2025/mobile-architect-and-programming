package com.example.inventoryapp1

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

abstract class BaseRepository(context: Context) {
    protected val dbHelper: DatabaseHelper = DatabaseHelper(context)

    protected fun insert(table: String, values: ContentValues): Long {
        val db = dbHelper.writableDatabase
        return try {
            db.insertOrThrow(table, null, values)
        } catch (e: Exception) {
            -1L
        }
    }

    protected fun update(table: String, values: ContentValues, whereClause: String, whereArgs: Array<String>): Boolean {
        val db = dbHelper.writableDatabase
        val rows = db.update(table, values, whereClause, whereArgs)
        return rows > 0
    }

    protected fun delete(table: String, whereClause: String, whereArgs: Array<String>): Boolean {
        val db = dbHelper.writableDatabase
        val rows = db.delete(table, whereClause, whereArgs)
        return rows > 0
    }

    protected fun query(
        table: String,
        columns: Array<String>? = null,
        selection: String? = null,
        selectionArgs: Array<String>? = null,
        groupBy: String? = null,
        having: String? = null,
        orderBy: String? = null
    ): Cursor {
        val db = dbHelper.readableDatabase
        return db.query(table, columns, selection, selectionArgs, groupBy, having, orderBy)
    }

    protected fun rawQuery(sql: String, selectionArgs: Array<String>? = null): Cursor {
        val db = dbHelper.readableDatabase
        return db.rawQuery(sql, selectionArgs)
    }
}