package com.example.inventoryapp1

import android.content.ContentValues
import android.database.Cursor
import android.content.Context

class InventoryRepository(context: Context) : BaseRepository(context)
{

    fun getAll(): List<InventoryItem> {
        val list = mutableListOf<InventoryItem>()
        val c: Cursor = rawQuery("SELECT id, name, quantity, category FROM items ORDER BY id DESC")

        c.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val name = it.getString(1)
                val qty = it.getInt(2)
                val cat = if (!it.isNull(3)) it.getString(3) else null
                list.add(InventoryItem(id, name, qty, cat))
            }
        }
        return list
    }

    fun add(item: InventoryItem): Long {
        val values = ContentValues().apply {
            put("name", item.name)
            put("quantity", item.quantity)
            put("category", item.category)
        }
        return insert("items", values)
    }

    fun update(item: InventoryItem): Boolean {
        val values = ContentValues().apply {
            put("name", item.name)
            put("quantity", item.quantity)
            put("category", item.category)
        }
        return update("items", values, "id=?", arrayOf(item.id.toString()))
    }

    fun delete(id: Long): Boolean {
        return delete("items", "id=?", arrayOf(id.toString()))
    }
}