package com.example.inventoryapp1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val items: MutableList<InventoryItem>,
    private val onUpdateClick: (position: Int, newName: String, newQuantity: Int) -> Unit,
    private val onDeleteClick: (position: Int) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InventoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.inventory_item, parent, false)
        return InventoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: InventoryViewHolder, position: Int) {
        val item = items[position]
        holder.itemName.setText(item.name)
        holder.itemQuantity.setText(item.quantity.toString())

        holder.updateButton.setOnClickListener {
            val name = holder.itemName.text.toString().trim()
            val qty = holder.itemQuantity.text.toString().trim().toIntOrNull() ?: item.quantity
            onUpdateClick(position, name, qty)
        }

        holder.deleteButton.setOnClickListener {
            onDeleteClick(position)
        }
    }

    override fun getItemCount(): Int = items.size

    inner class InventoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val itemName: EditText = view.findViewById(R.id.itemNameEdit)
        val itemQuantity: EditText = view.findViewById(R.id.itemQuantityEdit)
        val updateButton: Button = view.findViewById(R.id.updateButton)
        val deleteButton: Button = view.findViewById(R.id.deleteButton)
    }
}
